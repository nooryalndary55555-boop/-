<?php
/**
 * إدارة الصيانة
 * Maintenance Management
 */
$pageTitle = 'إدارة الصيانة';
$currentPage = 'maintenance';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$maintenance = $pdo->query("
    SELECT m.*, rm.room_number 
    FROM maintenance m 
    JOIN rooms rm ON m.room_id = rm.room_id 
    ORDER BY m.created_at DESC
")->fetchAll();

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number")->fetchAll();

$mainStatuses = ['pending' => 'قيد الانتظار', 'in_progress' => 'جاري العمل', 'completed' => 'مكتمل'];

require_once __DIR__ . '/../includes/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-tools"></i> طلبات الصيانة</h2>
        <div class="table-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="بحث...">
            </div>
            <button class="btn btn-primary" onclick="openModal('maintenanceModal')">
                <i class="fas fa-plus"></i> طلب صيانة جديد
            </button>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>رقم الطلب</th>
                <th>رقم الغرفة</th>
                <th>وصف العطل</th>
                <th>تاريخ الطلب</th>
                <th>جهة التواصل</th>
                <th>حالة الطلب</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($maintenance)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--gray);">لا توجد طلبات صيانة</td></tr>
            <?php else: ?>
                <?php foreach ($maintenance as $maint): ?>
                    <tr>
                        <td><strong>#<?= $maint['request_id'] ?></strong></td>
                        <td><span class="badge badge-info"><?= sanitize($maint['room_number']) ?></span></td>
                        <td><?= sanitize($maint['fault_description']) ?></td>
                        <td><?= $maint['request_date'] ?></td>
                        <td><?= sanitize($maint['contact_info'] ?? '-') ?></td>
                        <td>
                            <span class="badge badge-<?= $maint['request_status'] ?>">
                                <?= $mainStatuses[$maint['request_status']] ?? $maint['request_status'] ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn-icon edit" onclick="editItem(<?= htmlspecialchars(json_encode($maint)) ?>, 'maintenanceModal')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= app_url('process/maintenance_process.php') ?>" class="inline-action-form" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $maint['request_id'] ?>">
<button type="submit" class="btn-icon delete" aria-label="حذف"><i class="fas fa-trash"></i></button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- مودال إضافة/تعديل صيانة -->
<div class="modal-overlay" id="maintenanceModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-wrench"></i> طلب صيانة جديد</h3>
            <button class="modal-close" onclick="closeModal('maintenanceModal')">&times;</button>
        </div>
        <form method="POST" action="<?= app_url('process/maintenance_process.php') ?>">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
            <div class="modal-body">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="request_id" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>الغرفة *</label>
                        <select name="room_id" class="form-control" required>
                            <option value="">اختر الغرفة</option>
                            <?php foreach ($rooms as $rm): ?>
                                <option value="<?= $rm['room_id'] ?>"><?= sanitize($rm['room_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>تاريخ الطلب *</label>
                        <input type="date" name="request_date" class="form-control" required value="<?= date('Y-m-d') ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>وصف العطل *</label>
                    <textarea name="fault_description" class="form-control" rows="3" required placeholder="صف العطل بالتفصيل..."></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>جهة التواصل</label>
                        <input type="text" name="contact_info" class="form-control" placeholder="رقم أو اسم جهة الصيانة">
                    </div>
                    <div class="form-group">
                        <label>حالة الطلب</label>
                        <select name="request_status" class="form-control">
                            <?php foreach ($mainStatuses as $key => $val): ?>
                                <option value="<?= $key ?>"><?= $val ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> حفظ</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('maintenanceModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
