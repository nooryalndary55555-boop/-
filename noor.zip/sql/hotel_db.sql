-- =============================================
-- نظام إدارة حجوزات الفنادق - قاعدة البيانات
-- Hotel Reservation Management System Database
-- =============================================

CREATE DATABASE IF NOT EXISTS hotel_management 
    CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;

USE hotel_management;

-- =============================================
-- جدول الإدارة (Administration)
-- =============================================
CREATE TABLE IF NOT EXISTS admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    permissions VARCHAR(50) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- جدول الموظفين - المستقبل (Receptionist/Employees)
-- =============================================
CREATE TABLE IF NOT EXISTS employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    shift_period VARCHAR(50),
    salary DECIMAL(10,2),
    shift_evaluation VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- جدول الغرف (Rooms)
-- =============================================
CREATE TABLE IF NOT EXISTS rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    room_type ENUM('single', 'double', 'suite', 'deluxe') NOT NULL DEFAULT 'single',
    night_price DECIMAL(10,2) NOT NULL,
    room_status ENUM('available', 'occupied', 'maintenance') NOT NULL DEFAULT 'available',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- جدول النزلاء (Guests)
-- =============================================
CREATE TABLE IF NOT EXISTS guests (
    guest_id INT AUTO_INCREMENT PRIMARY KEY,
    national_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    nationality VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- جدول الحجوزات (Reservations)
-- =============================================
CREATE TABLE IF NOT EXISTS reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    guest_id INT NOT NULL,
    room_id INT NOT NULL,
    employee_id INT,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    total_price DECIMAL(10,2),
    status ENUM('confirmed', 'checked_in', 'checked_out', 'cancelled') DEFAULT 'confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (guest_id) REFERENCES guests(guest_id) ON DELETE RESTRICT,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE RESTRICT,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =============================================
-- جدول الصيانة (Maintenance)
-- =============================================
CREATE TABLE IF NOT EXISTS maintenance (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    fault_description TEXT NOT NULL,
    request_status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    request_date DATE NOT NULL,
    contact_info VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =============================================
-- بيانات تجريبية (Sample Data)
-- =============================================

-- إضافة مدير افتراضي (كلمة المرور: admin123)
INSERT INTO admins (username, password, full_name, permissions) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'admin');

-- إضافة موظفين
INSERT INTO employees (full_name, phone, email, shift_period, salary, shift_evaluation) VALUES
('أحمد محمد العلي', '0501234567', 'ahmed@hotel.com', 'صباحي', 5000.00, 'ممتاز'),
('سارة عبدالله الخالد', '0557654321', 'sara@hotel.com', 'مسائي', 4800.00, 'جيد جداً'),
('خالد سعد المطيري', '0569876543', 'khaled@hotel.com', 'ليلي', 5200.00, 'ممتاز');

-- إضافة غرف
INSERT INTO rooms (room_number, room_type, night_price, room_status, description) VALUES
('101', 'single', 250.00, 'available', 'غرفة مفردة مع إطلالة على الحديقة'),
('102', 'single', 250.00, 'available', 'غرفة مفردة مع إطلالة داخلية'),
('201', 'double', 450.00, 'available', 'غرفة مزدوجة مع شرفة'),
('202', 'double', 450.00, 'occupied', 'غرفة مزدوجة مع إطلالة على البحر'),
('301', 'suite', 800.00, 'available', 'جناح فاخر مع غرفة معيشة'),
('302', 'suite', 850.00, 'maintenance', 'جناح فاخر مع جاكوزي'),
('401', 'deluxe', 1200.00, 'available', 'جناح ملكي فاخر'),
('402', 'deluxe', 1500.00, 'available', 'الجناح الرئاسي');

-- إضافة نزلاء
INSERT INTO guests (national_id, full_name, phone, nationality) VALUES
('1234567890', 'عبدالرحمن محمد الأحمد', '0551112233', 'سعودي'),
('9876543210', 'فاطمة علي الحسن', '0554445566', 'إماراتي'),
('1122334455', 'محمد إبراهيم الشمري', '0557778899', 'كويتي');

-- إضافة حجوزات
INSERT INTO reservations (guest_id, room_id, employee_id, check_in_date, check_out_date, total_price, status) VALUES
(1, 4, 1, '2026-11-15', '2026-11-20', 2250.00, 'checked_in'),
(2, 1, 2, '2026-11-18', '2026-11-22', 1000.00, 'confirmed'),
(3, 5, 1, '2026-11-20', '2026-11-25', 4000.00, 'confirmed');

-- إضافة طلبات صيانة
INSERT INTO maintenance (room_id, fault_description, request_status, request_date, contact_info) VALUES
(6, 'عطل في نظام التكييف', 'in_progress', '2026-11-15', 'شركة التكييف - 0500001111'),
(2, 'تسريب مياه في الحمام', 'pending', '2026-11-17', 'قسم الصيانة الداخلي');
