        </div><!-- end content-area -->
    </main>
</div><!-- end app-layout -->

<script src="<?= app_url('js/main.js') ?>"></script>
</body>
</html>
