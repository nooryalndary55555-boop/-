<?php require_once __DIR__ . '/../config/database.php'; ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'نظام إدارة الفندق' ?></title>
    <link rel="stylesheet" href="<?= app_url('css/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
    <!-- الشريط الجانبي -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo">🏨</div>
            <h2>نظام إدارة الفندق</h2>
            <span>Hotel Management System</span>
        </div>
        
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">القائمة الرئيسية</div>
                <a href="<?= app_url('dashboard.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'dashboard' ? 'active' : '' ?>">
                    <i class="fas fa-th-large"></i>
                    <span>لوحة التحكم</span>
                </a>
            </div>
            
            <div class="nav-section">
                <div class="nav-section-title">إدارة العمليات</div>
                <a href="<?= app_url('pages/rooms.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'rooms' ? 'active' : '' ?>">
                    <i class="fas fa-door-open"></i>
                    <span>إدارة الغرف</span>
                </a>
                <a href="<?= app_url('pages/reservations.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'reservations' ? 'active' : '' ?>">
                    <i class="fas fa-calendar-check"></i>
                    <span>إدارة الحجوزات</span>
                </a>
                <a href="<?= app_url('pages/guests.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'guests' ? 'active' : '' ?>">
                    <i class="fas fa-users"></i>
                    <span>إدارة النزلاء</span>
                </a>
            </div>
            
            <div class="nav-section">
                <div class="nav-section-title">الإدارة</div>
                <a href="<?= app_url('pages/employees.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'employees' ? 'active' : '' ?>">
                    <i class="fas fa-user-tie"></i>
                    <span>إدارة الموظفين</span>
                </a>
                <a href="<?= app_url('pages/maintenance.php') ?>" class="nav-link <?= ($currentPage ?? '') === 'maintenance' ? 'active' : '' ?>">
                    <i class="fas fa-tools"></i>
                    <span>إدارة الصيانة</span>
                </a>
            </div>
        </nav>
        
        <div class="sidebar-footer">
            <form method="POST" action="<?= app_url('process/logout.php') ?>" class="logout-form">
                <input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
                <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i><span>تسجيل الخروج</span></button>
            </form>
        </div>
    </aside>
    
    <!-- المحتوى الرئيسي -->
    <main class="main-content">
        <div class="top-bar">
            <button class="mobile-toggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1><?= sanitize($pageTitle ?? 'لوحة التحكم') ?></h1>
            <div class="date-time" id="current-datetime"></div>
        </div>
        
        <div class="content-area">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?= sanitize($_SESSION['success']); unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= sanitize($_SESSION['error']); unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>
