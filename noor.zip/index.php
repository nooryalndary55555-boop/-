<?php
/**
 * صفحة تسجيل الدخول
 * Login Page
 */
require_once __DIR__ . '/config/database.php';

// إذا كان مسجل دخول بالفعل
if (isLoggedIn()) {
    header('Location: ' . app_url('dashboard.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['admin_permissions'] = $admin['permissions'];
            header('Location: ' . app_url('dashboard.php'));
            exit;
        } else {
            // للتسهيل: قبول كلمة مرور admin123 مباشرة
            if ($admin && $password === 'admin123') {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_permissions'] = $admin['permissions'];
                
                // تحديث كلمة المرور المشفرة
                $hashed = password_hash('admin123', PASSWORD_DEFAULT);
                $update = $pdo->prepare("UPDATE admins SET password = ? WHERE admin_id = ?");
                $update->execute([$hashed, $admin['admin_id']]);
                
                header('Location: ' . app_url('dashboard.php'));
                exit;
            }
            $error = 'اسم المستخدم أو كلمة المرور غير صحيحة';
        }
    } else {
        $error = 'يرجى إدخال اسم المستخدم وكلمة المرور';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - نظام إدارة الفندق</title>
    <link rel="stylesheet" href="<?= app_url('css/style.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-page">
        <div class="login-container">
            <div class="login-logo">
                🏨
            </div>
            <h1>نظام إدارة الفندق</h1>
            <p>Hotel Management System</p>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= $error ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user"></i> اسم المستخدم</label>
                    <input type="text" id="username" name="username" class="form-control" 
                           placeholder="أدخل اسم المستخدم" required 
                           value="<?= sanitize($_POST['username'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> كلمة المرور</label>
                    <input type="password" id="password" name="password" class="form-control" 
                           placeholder="أدخل كلمة المرور" required>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; margin-top: 10px;">
                    <i class="fas fa-sign-in-alt"></i>
                    تسجيل الدخول
                </button>
            </form>
            
            <p style="margin-top: 25px; font-size: 0.75rem; color: #95a5a6;">
                بيانات الدخول الافتراضية: admin / admin123
            </p>
        </div>
    </div>
</body>
</html>
