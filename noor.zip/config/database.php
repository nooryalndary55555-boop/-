<?php
$db_host='localhost'; $db_name='hotel_management'; $db_user='root'; $db_pass='';
try {
 $pdo=new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",$db_user,$db_pass,[
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  PDO::ATTR_EMULATE_PREPARES=>false
 ]);
} catch(PDOException $e) {
 error_log($e->getMessage()); http_response_code(500);
 die('تعذر الاتصال بقاعدة البيانات. تحقق من تشغيل MySQL واستيراد قاعدة البيانات.');
}
if(session_status()===PHP_SESSION_NONE) {
 $secure=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
 session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>$secure]);
 session_start();
}
function app_base_url(): string {
 static $base=null; if($base!==null)return $base;
 $dir=dirname(str_replace('\\','/',$_SERVER['SCRIPT_NAME']??''));
 if(in_array(basename($dir),['pages','process','config','includes'],true))$dir=dirname($dir);
 $base=($dir==='/'||$dir==='.'?'':rtrim($dir,'/')); return $base;
}
function app_url(string $path=''): string { return app_base_url().'/'.ltrim($path,'/'); }
function isLoggedIn(): bool { return isset($_SESSION['admin_id']); }
function requireLogin(): void { if(!isLoggedIn()){header('Location: '.app_url('index.php'));exit;} }
function sanitize($v): string { return htmlspecialchars(trim((string)$v),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function clean_input($v): string { return trim((string)$v); }
function csrf_token(): string { if(empty($_SESSION['csrf_token']))$_SESSION['csrf_token']=bin2hex(random_bytes(32)); return $_SESSION['csrf_token']; }
function verify_csrf(): void { $t=$_POST['csrf_token']??''; if(!$t||!hash_equals(csrf_token(),$t)){http_response_code(403);exit('انتهت صلاحية النموذج. أعد تحميل الصفحة.');} }
function redirect_to(string $p): void { header('Location: '.app_url($p)); exit; }
function sync_room_status(PDO $pdo,int $id): void {
 $m=$pdo->prepare("SELECT COUNT(*) FROM maintenance WHERE room_id=? AND request_status IN ('pending','in_progress')");$m->execute([$id]);
 if((int)$m->fetchColumn()>0)$status='maintenance';
 else {$r=$pdo->prepare("SELECT COUNT(*) FROM reservations WHERE room_id=? AND status='checked_in' AND check_in_date<=CURDATE() AND check_out_date>CURDATE()");$r->execute([$id]);$status=(int)$r->fetchColumn()>0?'occupied':'available';}
 $pdo->prepare("UPDATE rooms SET room_status=? WHERE room_id=?")->execute([$status,$id]);
}
?>
