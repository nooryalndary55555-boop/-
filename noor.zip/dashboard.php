<?php
/**
 * لوحة التحكم الرئيسية
 * Main Dashboard
 */
$pageTitle = 'لوحة التحكم';
$currentPage = 'dashboard';
require_once __DIR__ . '/config/database.php';
requireLogin();

// إحصائيات
$totalRooms = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$availableRooms = $pdo->query("SELECT COUNT(*) FROM rooms WHERE room_status = 'available'")->fetchColumn();
$totalReservations = $pdo->query("SELECT COUNT(*) FROM reservations")->fetchColumn();
$activeReservations = $pdo->query("SELECT COUNT(*) FROM reservations WHERE status IN ('confirmed', 'checked_in')")->fetchColumn();
$totalGuests = $pdo->query("SELECT COUNT(*) FROM guests")->fetchColumn();
$pendingMaintenance = $pdo->query("SELECT COUNT(*) FROM maintenance WHERE request_status = 'pending'")->fetchColumn();

// آخر الحجوزات
$recentReservations = $pdo->query("
    SELECT r.*, g.full_name as guest_name, rm.room_number, rm.room_type 
    FROM reservations r 
    JOIN guests g ON r.guest_id = g.guest_id 
    JOIN rooms rm ON r.room_id = rm.room_id 
    ORDER BY r.created_at DESC 
    LIMIT 5
")->fetchAll();

// طلبات الصيانة الأخيرة
$recentMaintenance = $pdo->query("
    SELECT m.*, rm.room_number 
    FROM maintenance m 
    JOIN rooms rm ON m.room_id = rm.room_id 
    ORDER BY m.created_at DESC 
    LIMIT 5
")->fetchAll();

require_once __DIR__ . '/includes/header.php';

// ترجمة أنواع الغرف
function roomTypeAr($type) {
    $types = ['single' => 'مفردة', 'double' => 'مزدوجة', 'suite' => 'جناح', 'deluxe' => 'ديلوكس'];
    return $types[$type] ?? $type;
}

// ترجمة حالة الحجز
function statusAr($status) {
    $statuses = [
        'confirmed' => 'مؤكد', 'checked_in' => 'نزيل حالي',
        'checked_out' => 'غادر', 'cancelled' => 'ملغي'
    ];
    return $statuses[$status] ?? $status;
}

// ترجمة حالة الصيانة
function mainStatusAr($status) {
    $statuses = ['pending' => 'قيد الانتظار', 'in_progress' => 'جاري العمل', 'completed' => 'مكتمل'];
    return $statuses[$status] ?? $status;
}
?>

<!-- البطاقات الإحصائية -->
<div class="stats-grid">
    <div class="stat-card blue">
        <div class="stat-icon blue">
            <i class="fas fa-door-open"></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalRooms ?></h3>
            <p>إجمالي الغرف (<?= $availableRooms ?> متاحة)</p>
        </div>
    </div>
    
    <div class="stat-card green">
        <div class="stat-icon green">
            <i class="fas fa-calendar-check"></i>
        </div>
        <div class="stat-info">
            <h3><?= $activeReservations ?></h3>
            <p>حجوزات نشطة من <?= $totalReservations ?></p>
        </div>
    </div>
    
    <div class="stat-card orange">
        <div class="stat-icon orange">
            <i class="fas fa-users"></i>
        </div>
        <div class="stat-info">
            <h3><?= $totalGuests ?></h3>
            <p>إجمالي النزلاء</p>
        </div>
    </div>
    
    <div class="stat-card red">
        <div class="stat-icon red">
            <i class="fas fa-tools"></i>
        </div>
        <div class="stat-info">
            <h3><?= $pendingMaintenance ?></h3>
            <p>طلبات صيانة معلقة</p>
        </div>
    </div>
</div>

<!-- آخر الحجوزات + الصيانة -->
<div class="dashboard-grid">
    <!-- آخر الحجوزات -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-calendar-check"></i> آخر الحجوزات</h3>
            <a href="<?= app_url('pages/reservations.php') ?>" class="btn btn-sm btn-primary">عرض الكل</a>
        </div>
        <div class="card-body">
            <?php if (empty($recentReservations)): ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>لا توجد حجوزات</h3>
                    <p>لم يتم إضافة أي حجوزات بعد</p>
                </div>
            <?php else: ?>
                <ul class="recent-list">
                    <?php foreach ($recentReservations as $res): ?>
                        <li class="recent-item">
                            <div class="guest-info">
                                <div class="guest-avatar">
                                    <?= mb_substr($res['guest_name'], 0, 1) ?>
                                </div>
                                <div>
                                    <strong><?= sanitize($res['guest_name']) ?></strong>
                                    <div style="font-size:0.8rem;color:var(--gray);">
                                        غرفة <?= sanitize($res['room_number']) ?> - <?= roomTypeAr($res['room_type']) ?>
                                    </div>
                                </div>
                            </div>
                            <span class="badge badge-<?= $res['status'] ?>">
                                <?= statusAr($res['status']) ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- طلبات الصيانة -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-tools"></i> طلبات الصيانة الأخيرة</h3>
            <a href="<?= app_url('pages/maintenance.php') ?>" class="btn btn-sm btn-primary">عرض الكل</a>
        </div>
        <div class="card-body">
            <?php if (empty($recentMaintenance)): ?>
                <div class="empty-state">
                    <i class="fas fa-tools"></i>
                    <h3>لا توجد طلبات صيانة</h3>
                </div>
            <?php else: ?>
                <ul class="recent-list">
                    <?php foreach ($recentMaintenance as $maint): ?>
                        <li class="recent-item">
                            <div class="guest-info">
                                <div class="guest-avatar" style="background: linear-gradient(135deg, var(--warning), var(--danger));">
                                    <?= sanitize($maint['room_number']) ?>
                                </div>
                                <div>
                                    <strong>غرفة <?= sanitize($maint['room_number']) ?></strong>
                                    <div style="font-size:0.8rem;color:var(--gray);">
                                        <?= mb_substr(sanitize($maint['fault_description']), 0, 40) ?>...
                                    </div>
                                </div>
                            </div>
                            <span class="badge badge-<?= $maint['request_status'] ?>">
                                <?= mainStatusAr($maint['request_status']) ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ملخص حالة الغرف -->
<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-chart-pie"></i> ملخص حالة الغرف</h2>
    </div>
    <div class="card-body">
        <div class="stats-grid" style="margin-bottom:0;">
            <?php
            $roomStats = $pdo->query("
                SELECT room_status, COUNT(*) as count 
                FROM rooms 
                GROUP BY room_status
            ")->fetchAll();
            
            $statusColors = ['available' => 'green', 'occupied' => 'orange', 'maintenance' => 'red'];
            $statusNames = ['available' => 'متاحة', 'occupied' => 'مشغولة', 'maintenance' => 'صيانة'];
            $statusIcons = ['available' => 'fa-check-circle', 'occupied' => 'fa-user-clock', 'maintenance' => 'fa-wrench'];
            
            foreach ($roomStats as $stat):
                $color = $statusColors[$stat['room_status']] ?? 'blue';
                $name = $statusNames[$stat['room_status']] ?? $stat['room_status'];
                $icon = $statusIcons[$stat['room_status']] ?? 'fa-info-circle';
            ?>
                <div class="stat-card <?= $color ?>">
                    <div class="stat-icon <?= $color ?>">
                        <i class="fas <?= $icon ?>"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?= $stat['count'] ?></h3>
                        <p>غرف <?= $name ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
