/**
 * =============================================
 * نظام إدارة حجوزات الفنادق - JavaScript
 * Hotel Reservation Management System
 * =============================================
 */

document.addEventListener('DOMContentLoaded', function() {
    initSidebar();
    initModals();
    initAlerts();
    initSearch();
    initDeleteConfirm();
    updateDateTime();
    setInterval(updateDateTime, 60000);
});

/**
 * === الشريط الجانبي ===
 */
function initSidebar() {
    const toggle = document.querySelector('.mobile-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.style.cssText = 'display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:999;';
    
    if (toggle && sidebar) {
        document.body.appendChild(overlay);
        
        toggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
            overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
        });
        
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('open');
            overlay.style.display = 'none';
        });
    }
}

/**
 * === المودال ===
 */
function initModals() {
    // إغلاق بالنقر على الخلفية
    document.querySelectorAll('.modal-overlay').forEach(function(overlay) {
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closeModal(overlay.id);
            }
        });
    });
    
    // إغلاق بزر Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.show').forEach(function(modal) {
                closeModal(modal.id);
            });
        }
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
        // إعادة تعيين النموذج
        const form = modal.querySelector('form');
        if (form) form.reset();
    }
}

/**
 * === التنبيهات ===
 */
function initAlerts() {
    document.querySelectorAll('.alert').forEach(function(alert) {
        setTimeout(function() {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(function() {
                alert.remove();
            }, 300);
        }, 5000);
    });
}

function showAlert(message, type) {
    type = type || 'info';
    var icons = {
        success: 'fas fa-check-circle',
        danger: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    
    var alert = document.createElement('div');
    alert.className = 'alert alert-' + type;
    const icon = document.createElement('i');
    icon.className = icons[type] || icons.info;
    alert.appendChild(icon);
    alert.appendChild(document.createTextNode(String(message)));
    
    var container = document.querySelector('.content-area');
    if (container) {
        container.insertBefore(alert, container.firstChild);
        initAlerts();
    }
}

/**
 * === البحث في الجداول ===
 */
function initSearch() {
    document.querySelectorAll('.search-box input').forEach(function(input) {
        input.addEventListener('input', function() {
            var searchText = this.value.toLowerCase();
            var container = this.closest('.table-container');
            var table = container ? container.querySelector('table') : null;
            if (!table) return;
            
            var rows = table.querySelectorAll('tbody tr');
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });
    });
}

/**
 * === تأكيد الحذف ===
 */
function initDeleteConfirm() {
    document.querySelectorAll('.delete-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            if (!confirm('هل أنت متأكد من حذف هذا العنصر؟')) {
                e.preventDefault();
            }
        });
    });
}

/**
 * === تحديث التاريخ والوقت ===
 */
function updateDateTime() {
    var el = document.getElementById('current-datetime');
    if (el) {
        var now = new Date();
        var options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        el.textContent = now.toLocaleDateString('ar-SA', options);
    }
}

/**
 * === تعبئة نموذج التعديل ===
 */
function editItem(data, modalId) {
    var modal = document.getElementById(modalId);
    if (!modal) return;
    
    Object.keys(data).forEach(function(key) {
        var input = modal.querySelector('[name="' + key + '"]');
        if (input) {
            if (input.type === 'checkbox') input.checked = Boolean(Number(data[key]));
            else input.value = data[key] == null ? '' : data[key];
        }
    });
    
    // تغيير عنوان المودال
    var title = modal.querySelector('.modal-header h3');
    if (title) {
        title.textContent = title.textContent.replace('إضافة', 'تعديل');
    }
    
    // إضافة حقل hidden للتعديل
    var form = modal.querySelector('form');
    if (form) {
        var existing = form.querySelector('input[name="action"]');
        if (existing) existing.value = 'update';
    }
    
    openModal(modalId);
}

/**
 * === حساب إجمالي السعر ===
 */
function calculateTotal() {
    var checkIn = document.querySelector('[name="check_in_date"]');
    var checkOut = document.querySelector('[name="check_out_date"]');
    var roomSelect = document.querySelector('[name="room_id"]');
    var totalField = document.getElementById('total_price_display');
    
    if (checkIn && checkOut && roomSelect && checkIn.value && checkOut.value) {
        var days = Math.ceil((new Date(checkOut.value) - new Date(checkIn.value)) / (1000 * 60 * 60 * 24));
        var selectedOption = roomSelect.options[roomSelect.selectedIndex];
        var price = selectedOption ? parseFloat(selectedOption.dataset.price) || 0 : 0;
        
        if (days > 0 && price > 0) {
            var total = days * price;
            if (totalField) totalField.textContent = total.toFixed(2) + ' ريال (' + days + ' ليالي)';
            var hiddenTotal = document.querySelector('[name="total_price"]');
            if (hiddenTotal) hiddenTotal.value = total.toFixed(2);
        }
    }
}
