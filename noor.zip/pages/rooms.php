<?php
/**
 * إدارة الغرف
 * Rooms Management
 */
$pageTitle = 'إدارة الغرف';
$currentPage = 'rooms';
require_once __DIR__ . '/../config/database.php';
requireLogin();

// جلب الغرف
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number ASC")->fetchAll();

$roomTypes = ['single' => 'مفردة', 'double' => 'مزدوجة', 'suite' => 'جناح', 'deluxe' => 'ديلوكس'];
$roomStatuses = ['available' => 'متاحة', 'occupied' => 'مشغولة', 'maintenance' => 'صيانة'];

require_once __DIR__ . '/../includes/header.php';
?>

<!-- رأس الجدول -->
<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-door-open"></i> قائمة الغرف</h2>
        <div class="table-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="بحث عن غرفة...">
            </div>
            <button class="btn btn-primary" onclick="openModal('roomModal')">
                <i class="fas fa-plus"></i> إضافة غرفة
            </button>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>رقم الغرفة</th>
                <th>نوع الغرفة</th>
                <th>سعر الليلة</th>
                <th>حالة الغرفة</th>
                <th>الوصف</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($rooms)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--gray);">لا توجد غرف مسجلة</td></tr>
            <?php else: ?>
                <?php foreach ($rooms as $i => $room): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= sanitize($room['room_number']) ?></strong></td>
                        <td><?= $roomTypes[$room['room_type']] ?? $room['room_type'] ?></td>
                        <td><?= number_format($room['night_price'], 2) ?> ريال</td>
                        <td>
                            <span class="badge badge-<?= $room['room_status'] ?>">
                                <?= $roomStatuses[$room['room_status']] ?? $room['room_status'] ?>
                            </span>
                        </td>
                        <td><?= mb_substr(sanitize($room['description'] ?? ''), 0, 30) ?></td>
                        <td>
                            <button class="btn-icon edit" onclick="editItem(<?= htmlspecialchars(json_encode($room)) ?>, 'roomModal')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= app_url('process/room_process.php') ?>" class="inline-action-form" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $room['room_id'] ?>">
<button type="submit" class="btn-icon delete" aria-label="حذف"><i class="fas fa-trash"></i></button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- مودال إضافة/تعديل غرفة -->
<div class="modal-overlay" id="roomModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-door-open"></i> إضافة غرفة جديدة</h3>
            <button class="modal-close" onclick="closeModal('roomModal')">&times;</button>
        </div>
        <form method="POST" action="<?= app_url('process/room_process.php') ?>">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
            <div class="modal-body">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="room_id" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>رقم الغرفة *</label>
                        <input type="text" name="room_number" class="form-control" required placeholder="مثال: 101">
                    </div>
                    <div class="form-group">
                        <label>نوع الغرفة *</label>
                        <select name="room_type" class="form-control" required>
                            <option value="">اختر النوع</option>
                            <?php foreach ($roomTypes as $key => $val): ?>
                                <option value="<?= $key ?>"><?= $val ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>سعر الليلة (ريال) *</label>
                        <input type="number" name="night_price" class="form-control" required step="0.01" min="0" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label>حالة الغرفة *</label>
                        <select name="room_status" class="form-control" required>
                            <?php foreach ($roomStatuses as $key => $val): ?>
                                <option value="<?= $key ?>"><?= $val ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>وصف الغرفة</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="وصف مختصر للغرفة..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success save-form-btn"><i class="fas fa-save"></i> حفظ البيانات</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('roomModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
