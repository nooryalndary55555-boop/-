<?php
/**
 * إدارة النزلاء
 * Guests Management
 */
$pageTitle = 'إدارة النزلاء';
$currentPage = 'guests';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$guests = $pdo->query("SELECT * FROM guests ORDER BY created_at DESC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-users"></i> قائمة النزلاء</h2>
        <div class="table-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="بحث عن نزيل...">
            </div>
            <button class="btn btn-primary" onclick="openModal('guestModal')">
                <i class="fas fa-plus"></i> إضافة نزيل
            </button>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>رقم الهوية</th>
                <th>الاسم الكامل</th>
                <th>رقم الهاتف</th>
                <th>الجنسية</th>
                <th>تاريخ التسجيل</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($guests)): ?>
                <tr><td colspan="7" style="text-align:center;padding:40px;color:var(--gray);">لا يوجد نزلاء مسجلين</td></tr>
            <?php else: ?>
                <?php foreach ($guests as $i => $guest): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><strong><?= sanitize($guest['national_id']) ?></strong></td>
                        <td>
                            <div class="guest-info" style="display:flex;align-items:center;gap:10px;">
                                <div class="guest-avatar" style="width:35px;height:35px;font-size:0.8rem;">
                                    <?= mb_substr($guest['full_name'], 0, 1) ?>
                                </div>
                                <?= sanitize($guest['full_name']) ?>
                            </div>
                        </td>
                        <td><?= sanitize($guest['phone']) ?></td>
                        <td><span class="badge badge-info"><?= sanitize($guest['nationality'] ?? 'غير محدد') ?></span></td>
                        <td><?= date('Y-m-d', strtotime($guest['created_at'])) ?></td>
                        <td>
                            <button class="btn-icon edit" onclick="editItem(<?= htmlspecialchars(json_encode($guest)) ?>, 'guestModal')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= app_url('process/guest_process.php') ?>" class="inline-action-form" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $guest['guest_id'] ?>">
<button type="submit" class="btn-icon delete" aria-label="حذف"><i class="fas fa-trash"></i></button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- مودال إضافة/تعديل نزيل -->
<div class="modal-overlay" id="guestModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> إضافة نزيل جديد</h3>
            <button class="modal-close" onclick="closeModal('guestModal')">&times;</button>
        </div>
        <form method="POST" action="<?= app_url('process/guest_process.php') ?>">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
            <div class="modal-body">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="guest_id" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>رقم الهوية *</label>
                        <input type="text" name="national_id" class="form-control" required placeholder="رقم الهوية الوطنية">
                    </div>
                    <div class="form-group">
                        <label>الاسم الكامل *</label>
                        <input type="text" name="full_name" class="form-control" required placeholder="الاسم الكامل للنزيل">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>رقم الهاتف *</label>
                        <input type="text" name="phone" class="form-control" required placeholder="05XXXXXXXX">
                    </div>
                    <div class="form-group">
                        <label>الجنسية</label>
                        <input type="text" name="nationality" class="form-control" placeholder="الجنسية">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success save-form-btn"><i class="fas fa-save"></i> حفظ البيانات</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('guestModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
