<?php
/**
 * إدارة الموظفين
 * Employees Management
 */
$pageTitle = 'إدارة الموظفين';
$currentPage = 'employees';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$employees = $pdo->query("SELECT * FROM employees ORDER BY created_at DESC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-user-tie"></i> قائمة الموظفين</h2>
        <div class="table-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="بحث عن موظف...">
            </div>
            <button class="btn btn-primary" onclick="openModal('employeeModal')">
                <i class="fas fa-plus"></i> إضافة موظف
            </button>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>الرقم الوظيفي</th>
                <th>الاسم</th>
                <th>الهاتف</th>
                <th>البريد الإلكتروني</th>
                <th>فترة المناوبة</th>
                <th>المرتب</th>
                <th>التقييم</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($employees)): ?>
                <tr><td colspan="8" style="text-align:center;padding:40px;color:var(--gray);">لا يوجد موظفين مسجلين</td></tr>
            <?php else: ?>
                <?php foreach ($employees as $emp): ?>
                    <tr>
                        <td><strong>#<?= $emp['employee_id'] ?></strong></td>
                        <td>
                            <div class="guest-info" style="display:flex;align-items:center;gap:10px;">
                                <div class="guest-avatar" style="width:35px;height:35px;font-size:0.8rem;background:linear-gradient(135deg,var(--secondary),var(--secondary-light));">
                                    <?= mb_substr($emp['full_name'], 0, 1) ?>
                                </div>
                                <?= sanitize($emp['full_name']) ?>
                            </div>
                        </td>
                        <td><?= sanitize($emp['phone']) ?></td>
                        <td><?= sanitize($emp['email'] ?? '-') ?></td>
                        <td><span class="badge badge-info"><?= sanitize($emp['shift_period'] ?? 'غير محدد') ?></span></td>
                        <td><?= number_format($emp['salary'] ?? 0, 2) ?> ريال</td>
                        <td><span class="badge badge-success"><?= sanitize($emp['shift_evaluation'] ?? '-') ?></span></td>
                        <td>
                            <button class="btn-icon edit" onclick="editItem(<?= htmlspecialchars(json_encode($emp)) ?>, 'employeeModal')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= app_url('process/employee_process.php') ?>" class="inline-action-form" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $emp['employee_id'] ?>">
<button type="submit" class="btn-icon delete" aria-label="حذف"><i class="fas fa-trash"></i></button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- مودال إضافة/تعديل موظف -->
<div class="modal-overlay" id="employeeModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-user-plus"></i> إضافة موظف جديد</h3>
            <button class="modal-close" onclick="closeModal('employeeModal')">&times;</button>
        </div>
        <form method="POST" action="<?= app_url('process/employee_process.php') ?>">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
            <div class="modal-body">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="employee_id" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>الاسم الكامل *</label>
                        <input type="text" name="full_name" class="form-control" required placeholder="اسم الموظف">
                    </div>
                    <div class="form-group">
                        <label>رقم الهاتف *</label>
                        <input type="text" name="phone" class="form-control" required placeholder="05XXXXXXXX">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>البريد الإلكتروني</label>
                        <input type="email" name="email" class="form-control" placeholder="email@hotel.com">
                    </div>
                    <div class="form-group">
                        <label>فترة المناوبة</label>
                        <select name="shift_period" class="form-control">
                            <option value="">اختر الفترة</option>
                            <option value="صباحي">صباحي</option>
                            <option value="مسائي">مسائي</option>
                            <option value="ليلي">ليلي</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>المرتب (ريال)</label>
                        <input type="number" name="salary" class="form-control" step="0.01" min="0" placeholder="0.00">
                    </div>
                    <div class="form-group">
                        <label>تقييم المناوبة</label>
                        <select name="shift_evaluation" class="form-control">
                            <option value="">اختر التقييم</option>
                            <option value="ممتاز">ممتاز</option>
                            <option value="جيد جداً">جيد جداً</option>
                            <option value="جيد">جيد</option>
                            <option value="مقبول">مقبول</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success save-form-btn"><i class="fas fa-save"></i> حفظ البيانات</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('employeeModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
