<?php
/**
 * إدارة الحجوزات
 * Reservations Management
 */
$pageTitle = 'إدارة الحجوزات';
$currentPage = 'reservations';
require_once __DIR__ . '/../config/database.php';
requireLogin();

// جلب الحجوزات مع بيانات النزيل والغرفة والموظف
$reservations = $pdo->query("
    SELECT r.*, g.full_name as guest_name, g.national_id,
           rm.room_number, rm.room_type, rm.night_price,
           e.full_name as employee_name
    FROM reservations r
    JOIN guests g ON r.guest_id = g.guest_id
    JOIN rooms rm ON r.room_id = rm.room_id
    LEFT JOIN employees e ON r.employee_id = e.employee_id
    ORDER BY r.created_at DESC
")->fetchAll();

// جلب النزلاء والغرف والموظفين للقوائم المنسدلة
$guests = $pdo->query("SELECT * FROM guests ORDER BY full_name")->fetchAll();
$availableRooms = $pdo->query("SELECT * FROM rooms WHERE room_status = 'available' ORDER BY room_number")->fetchAll();
$allRooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number")->fetchAll();
$employees = $pdo->query("SELECT * FROM employees ORDER BY full_name")->fetchAll();

$statuses = [
    'confirmed' => 'مؤكد', 'checked_in' => 'نزيل حالي',
    'checked_out' => 'غادر', 'cancelled' => 'ملغي'
];
$roomTypes = ['single' => 'مفردة', 'double' => 'مزدوجة', 'suite' => 'جناح', 'deluxe' => 'ديلوكس'];

require_once __DIR__ . '/../includes/header.php';
?>

<div class="table-container">
    <div class="table-header">
        <h2><i class="fas fa-calendar-check"></i> قائمة الحجوزات</h2>
        <div class="table-actions">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="بحث عن حجز...">
            </div>
            <button class="btn btn-primary" onclick="openModal('reservationModal')">
                <i class="fas fa-plus"></i> حجز جديد
            </button>
        </div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>رقم الحجز</th>
                <th>النزيل</th>
                <th>الغرفة</th>
                <th>تاريخ الوصول</th>
                <th>تاريخ المغادرة</th>
                <th>الإجمالي</th>
                <th>الموظف المستقبل</th>
                <th>الحالة</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($reservations)): ?>
                <tr><td colspan="9" style="text-align:center;padding:40px;color:var(--gray);">لا توجد حجوزات</td></tr>
            <?php else: ?>
                <?php foreach ($reservations as $res): ?>
                    <tr>
                        <td><strong>#<?= $res['reservation_id'] ?></strong></td>
                        <td>
                            <div>
                                <strong><?= sanitize($res['guest_name']) ?></strong>
                                <div style="font-size:0.75rem;color:var(--gray);"><?= sanitize($res['national_id']) ?></div>
                            </div>
                        </td>
                        <td><?= sanitize($res['room_number']) ?> (<?= $roomTypes[$res['room_type']] ?? '' ?>)</td>
                        <td><?= $res['check_in_date'] ?></td>
                        <td><?= $res['check_out_date'] ?></td>
                        <td><?= number_format($res['total_price'], 2) ?> ريال</td>
                        <td><?= sanitize($res['employee_name'] ?? 'غير محدد') ?></td>
                        <td>
                            <span class="badge badge-<?= $res['status'] ?>">
                                <?= $statuses[$res['status']] ?? $res['status'] ?>
                            </span>
                        </td>
                        <td>
                            <button class="btn-icon edit" onclick="editItem(<?= htmlspecialchars(json_encode($res)) ?>, 'reservationModal')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <form method="POST" action="<?= app_url('process/reservation_process.php') ?>" class="inline-action-form" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $res['reservation_id'] ?>">
<button type="submit" class="btn-icon delete" aria-label="حذف"><i class="fas fa-trash"></i></button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- مودال إضافة/تعديل حجز -->
<div class="modal-overlay" id="reservationModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-calendar-plus"></i> إضافة حجز جديد</h3>
            <button class="modal-close" onclick="closeModal('reservationModal')">&times;</button>
        </div>
        <form method="POST" action="<?= app_url('process/reservation_process.php') ?>">
<input type="hidden" name="csrf_token" value="<?= sanitize(csrf_token()) ?>">
            <div class="modal-body">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="reservation_id" value="">
                <input type="hidden" name="total_price" value="">
                
                <div class="form-row">
                    <div class="form-group">
                        <label>النزيل *</label>
                        <select name="guest_id" class="form-control" required>
                            <option value="">اختر النزيل</option>
                            <?php foreach ($guests as $g): ?>
                                <option value="<?= $g['guest_id'] ?>"><?= sanitize($g['full_name']) ?> (<?= $g['national_id'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>الغرفة *</label>
                        <select name="room_id" class="form-control" required onchange="calculateTotal()">
                            <option value="">اختر الغرفة</option>
                            <?php foreach ($allRooms as $rm): ?>
                                <option value="<?= $rm['room_id'] ?>" data-price="<?= $rm['night_price'] ?>">
                                    <?= sanitize($rm['room_number']) ?> - <?= $roomTypes[$rm['room_type']] ?? '' ?> (<?= $rm['night_price'] ?> ريال/ليلة)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>تاريخ الوصول *</label>
                        <input type="date" name="check_in_date" class="form-control" required onchange="calculateTotal()">
                    </div>
                    <div class="form-group">
                        <label>تاريخ المغادرة *</label>
                        <input type="date" name="check_out_date" class="form-control" required onchange="calculateTotal()">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>الموظف المستقبل</label>
                        <select name="employee_id" class="form-control">
                            <option value="">اختر الموظف</option>
                            <?php foreach ($employees as $emp): ?>
                                <option value="<?= $emp['employee_id'] ?>"><?= sanitize($emp['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>حالة الحجز</label>
                        <select name="status" class="form-control">
                            <?php foreach ($statuses as $key => $val): ?>
                                <option value="<?= $key ?>"><?= $val ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>الإجمالي المحسوب:</label>
                    <div id="total_price_display" style="font-size:1.2rem;font-weight:700;color:var(--success);padding:10px 0;">
                        اختر الغرفة والتواريخ لحساب الإجمالي
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success save-form-btn"><i class="fas fa-save"></i> حفظ الحجز</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('reservationModal')">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
