<?php
require_once __DIR__.'/../config/database.php';requireLogin();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('طريقة طلب غير مسموحة');}verify_csrf();$a=$_POST['action']??'';
try{
 if($a==='create'||$a==='update'){
  $num=clean_input($_POST['room_number']??'');$type=clean_input($_POST['room_type']??'');$price=filter_var($_POST['night_price']??null,FILTER_VALIDATE_FLOAT);$status=clean_input($_POST['room_status']??'available');
  if(!$num||!in_array($type,['single','double','suite','deluxe'],true)||$price===false||$price<0||!in_array($status,['available','occupied','maintenance'],true))throw new RuntimeException('تحقق من بيانات الغرفة.');
  $v=[$num,$type,$price,$status,clean_input($_POST['description']??'')];
  if($a==='create'){$pdo->prepare('INSERT INTO rooms(room_number,room_type,night_price,room_status,description) VALUES(?,?,?,?,?)')->execute($v);$_SESSION['success']='تم إضافة الغرفة بنجاح';}
  else{$id=(int)($_POST['room_id']??0);$m=$pdo->prepare("SELECT COUNT(*) FROM maintenance WHERE room_id=? AND request_status IN ('pending','in_progress')");$m->execute([$id]);$r=$pdo->prepare("SELECT COUNT(*) FROM reservations WHERE room_id=? AND status='checked_in' AND check_in_date<=CURDATE() AND check_out_date>CURDATE()");$r->execute([$id]);if((int)$m->fetchColumn())$v[3]='maintenance';elseif((int)$r->fetchColumn())$v[3]='occupied';$pdo->prepare('UPDATE rooms SET room_number=?,room_type=?,night_price=?,room_status=?,description=? WHERE room_id=?')->execute([...$v,$id]);$_SESSION['success']='تم تعديل بيانات الغرفة بنجاح';}
 }elseif($a==='delete'){$id=(int)($_POST['id']??0);$q=$pdo->prepare('SELECT (SELECT COUNT(*) FROM reservations WHERE room_id=?)+(SELECT COUNT(*) FROM maintenance WHERE room_id=?)');$q->execute([$id,$id]);if((int)$q->fetchColumn())throw new RuntimeException('لا يمكن حذف الغرفة لارتباطها بحجوزات أو صيانة.');$pdo->prepare('DELETE FROM rooms WHERE room_id=?')->execute([$id]);$_SESSION['success']='تم حذف الغرفة بنجاح';}
 else throw new RuntimeException('إجراء غير صالح');
}catch(Throwable $e){error_log($e->getMessage());$_SESSION['error']=$e instanceof PDOException?'تعذر تنفيذ العملية. قد يكون رقم الغرفة مستخدماً.':$e->getMessage();}
redirect_to('pages/rooms.php');
