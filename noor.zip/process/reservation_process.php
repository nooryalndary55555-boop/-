<?php
require_once __DIR__.'/../config/database.php'; requireLogin();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('طريقة طلب غير مسموحة');} verify_csrf();
$a=$_POST['action']??'';
try{
 $pdo->beginTransaction();
 if($a==='create'||$a==='update'){
  $guest=(int)($_POST['guest_id']??0);$room=(int)($_POST['room_id']??0);$employee=!empty($_POST['employee_id'])?(int)$_POST['employee_id']:null;
  $ci=clean_input($_POST['check_in_date']??'');$co=clean_input($_POST['check_out_date']??'');$status=clean_input($_POST['status']??'confirmed');
  $in=DateTime::createFromFormat('!Y-m-d',$ci);$out=DateTime::createFromFormat('!Y-m-d',$co);
  if(!$in||!$out||$in->format('Y-m-d')!==$ci||$out->format('Y-m-d')!==$co||$out<=$in)throw new RuntimeException('تاريخ المغادرة يجب أن يكون بعد تاريخ الوصول.');
  if(!in_array($status,['confirmed','checked_in','checked_out','cancelled'],true))throw new RuntimeException('حالة الحجز غير صحيحة.');
  $q=$pdo->prepare("SELECT night_price,room_status FROM rooms WHERE room_id=? FOR UPDATE");$q->execute([$room]);$rd=$q->fetch();
  if(!$rd)throw new RuntimeException('الغرفة المحددة غير موجودة.');
  if($rd['room_status']==='maintenance')throw new RuntimeException('لا يمكن حجز غرفة تحت الصيانة.');
  $q=$pdo->prepare('SELECT COUNT(*) FROM guests WHERE guest_id=?');$q->execute([$guest]);if(!(int)$q->fetchColumn())throw new RuntimeException('النزيل المحدد غير موجود.');
  $id=(int)($_POST['reservation_id']??0);
  $sql="SELECT COUNT(*) FROM reservations WHERE room_id=? AND status IN ('confirmed','checked_in') AND check_in_date < ? AND check_out_date > ?";$params=[$room,$co,$ci];
  if($a==='update'){$sql.=' AND reservation_id<>?';$params[]=$id;}
  $q=$pdo->prepare($sql);$q->execute($params);if((int)$q->fetchColumn())throw new RuntimeException('الغرفة محجوزة خلال هذه الفترة.');
  $total=(int)$in->diff($out)->days*(float)$rd['night_price'];
  if($a==='create'){$pdo->prepare("INSERT INTO reservations(guest_id,room_id,employee_id,check_in_date,check_out_date,total_price,status) VALUES(?,?,?,?,?,?,?)")->execute([$guest,$room,$employee,$ci,$co,$total,$status]);$_SESSION['success']='تم إضافة الحجز بنجاح - الإجمالي: '.number_format($total,2).' ريال';}
  else{$q=$pdo->prepare('SELECT room_id FROM reservations WHERE reservation_id=? FOR UPDATE');$q->execute([$id]);$old=(int)$q->fetchColumn();if(!$old)throw new RuntimeException('الحجز غير موجود.');$pdo->prepare('UPDATE reservations SET guest_id=?,room_id=?,employee_id=?,check_in_date=?,check_out_date=?,total_price=?,status=? WHERE reservation_id=?')->execute([$guest,$room,$employee,$ci,$co,$total,$status,$id]);sync_room_status($pdo,$old);$_SESSION['success']='تم تعديل الحجز بنجاح';}
  sync_room_status($pdo,$room);
 }elseif($a==='delete'){$id=(int)($_POST['id']??0);$q=$pdo->prepare('SELECT room_id FROM reservations WHERE reservation_id=?');$q->execute([$id]);$room=(int)$q->fetchColumn();$pdo->prepare('DELETE FROM reservations WHERE reservation_id=?')->execute([$id]);if($room)sync_room_status($pdo,$room);$_SESSION['success']='تم حذف الحجز بنجاح';}
 else throw new RuntimeException('إجراء غير صالح');
 $pdo->commit();
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log($e->getMessage());$_SESSION['error']=$e instanceof PDOException?'تعذر تنفيذ عملية الحجز. تحقق من البيانات.':$e->getMessage();}
redirect_to('pages/reservations.php');
