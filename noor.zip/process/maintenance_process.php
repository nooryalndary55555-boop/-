<?php
require_once __DIR__.'/../config/database.php';requireLogin();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('طريقة طلب غير مسموحة');}verify_csrf();$a=$_POST['action']??'';
try{$pdo->beginTransaction();
 if($a==='create'||$a==='update'){
  $room=(int)($_POST['room_id']??0);$desc=clean_input($_POST['fault_description']??'');$status=clean_input($_POST['request_status']??'pending');$date=clean_input($_POST['request_date']??'');
  if(!$room||!$desc||!in_array($status,['pending','in_progress','completed'],true)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date))throw new RuntimeException('تحقق من بيانات طلب الصيانة.');
  $q=$pdo->prepare('SELECT room_id FROM rooms WHERE room_id=?');$q->execute([$room]);if(!$q->fetch())throw new RuntimeException('الغرفة غير موجودة.');
  if($a==='create'){$pdo->prepare('INSERT INTO maintenance(room_id,fault_description,request_status,request_date,contact_info) VALUES(?,?,?,?,?)')->execute([$room,$desc,$status,$date,clean_input($_POST['contact_info']??'')]);}
  else{$id=(int)($_POST['request_id']??0);$q=$pdo->prepare('SELECT room_id FROM maintenance WHERE request_id=?');$q->execute([$id]);$old=(int)$q->fetchColumn();$pdo->prepare('UPDATE maintenance SET room_id=?,fault_description=?,request_status=?,request_date=?,contact_info=? WHERE request_id=?')->execute([$room,$desc,$status,$date,clean_input($_POST['contact_info']??''),$id]);if($old)sync_room_status($pdo,$old);}
  sync_room_status($pdo,$room);$_SESSION['success']=$a==='create'?'تم إضافة طلب الصيانة بنجاح':'تم تعديل طلب الصيانة بنجاح';
 }elseif($a==='delete'){$id=(int)($_POST['id']??0);$q=$pdo->prepare('SELECT room_id FROM maintenance WHERE request_id=?');$q->execute([$id]);$room=(int)$q->fetchColumn();$pdo->prepare('DELETE FROM maintenance WHERE request_id=?')->execute([$id]);if($room)sync_room_status($pdo,$room);$_SESSION['success']='تم حذف طلب الصيانة بنجاح';}
 else throw new RuntimeException('إجراء غير صالح');$pdo->commit();
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log($e->getMessage());$_SESSION['error']=$e instanceof PDOException?'تعذر تنفيذ عملية الصيانة.':$e->getMessage();}
redirect_to('pages/maintenance.php');
